
// PROBLEMA: CÓDIGO EXTENSO, POR CAUSA DE getElementById.
// SOLUÇÃO jquery $('.class').value....etc: PROBLEMA: A SOLUÇÃO NÃO FUNCIONA


var cont, caso, num; // VARIAVEIS GLOBAIS

//FUNÇÃO PARA PEGAR A DATA ATUAL
var data = new Date();

var diaAtual = data.getDate(); // PEGA O DIA ATUAL

var mesAtual = (data.getMonth()+1); // PEGA O MÊS ATUAL 0-11 (0 = janeiro)-(11 = dezembro)

var anoAtual = data.getFullYear(); // PEGA O ANO ATUAL

var horaAtual = data.getHours(); // PEGA A HORA ATUAL

var minAtual = data.getMinutes(); // PEGA OS MINUTOS ATUAIS
//////////////////////////////////////////////////////
if(diaAtual <= 9){diaAtual = '0'+diaAtual} // FORMATANDO O DIA
if (mesAtual <= 9){mesAtual = '0'+mesAtual} // FORMATANDO O MÊS
/////////////////////////////////////////////////////
var dataAtual = diaAtual+'/'+mesAtual+'/'+anoAtual; // DATA COMPLETA = DD/MM/YYYY

// FUNÇÃO PARA ATRIBUIR DATA COMPLETA
function dataC(Campo, Campo2){
// ATRIBUINDO DADOS AO OBJ-HTML
document.getElementById(Campo).value = dataAtual;
// ATRIBUINDO COR AO OBJ-HTML
document.getElementById(Campo).style.color = '#00ad5f';


if (Campo2 != null){
////////////////////////////////////////////////////////
document.getElementById(Campo2).value = dataAtual;
// ATRIBUINDO COR AO OBJ-HTML
document.getElementById(Campo2).style.color = '#00ad5f';
}else{}

}

// FUNÇÃO PARA ATRIBUIR APENAS O ANO ATUAL
function AnoAtual(Campo){
// ATRIBUINDO DADOS AO OBJ-HTML
document.getElementById(Campo).value = anoAtual;
// ATRIBUINDO COR AO OBJ-HTML
document.getElementById(Campo).style.color = '#00ad5f';

}
//////////////////////////////////////////////////////////////////////////////////

// COMPARADOR DE SENHAS
function validarSenha(Campo, Campo2)
{
// PEGANDO VALORES
    var senha1 = document.getElementById(Campo).value;
    var senha2 = document.getElementById(Campo2).value;
//////////////////////////////////////////////////////////////
// VERIFICANDO SE SÃO NULAS OU IGUAIS
    if (senha1 === senha2){
        // ATRIBUIDO COR
    document.getElementById(Campo).style.color = "#00ad5f";
    document.getElementById(Campo2).style.color = "#00ad5f";
///////////////////////////////////////////////////////////////////////
// ATRIBUIDO BORDA
    document.getElementById(Campo).style.border = "1px solid #00ad5f";
    document.getElementById(Campo2).style.border = "1px solid #00ad5f";
////////////////////////////////////////////////////////////////////////
    document.getElementById(Campo).type = "password";
    document.getElementById(Campo2).type = "password";
    }
    else{ 
// ATRIBUINDO ELEMENTO NULO AOS DOIS CAMPOS
    document.getElementById(Campo).value = "";
    document.getElementById(Campo2).value = "";
// ATRIBUIDO NOVOS PLACEHOLDER's AOS DOIS CAMPOS
    document.getElementById(Campo).placeholder = "*Incompatível*";
    document.getElementById(Campo2).placeholder = "*Incompatível*";
// ATRIBUIDO BORDA AOS CAMPOS       
    document.getElementById(Campo).style.border = "1px solid red";
    document.getElementById(Campo2).style.border = "1px solid red";
///////////////////////////////////////////////////////////////////////
}}
// FUNÇÃO AÇÃO DO BOTÃO LIMPAR/////////////////////////////////////////
function limpar(){
    window.location.reload()
}
// FUNÇÃO DE ALERTA
function alerta(msg){
    alert(msg);
}
// FUNÇÃO DE ESCREVER NA TELA
function escrever(texto){
    document.write(texto);
}
// FUNÇÃO DE VERIFICAÇÃO DE NÚMERO
function numVal(numero){

    num = document.getElementById(numero).value;
if (num <= 0){
    document.getElementById(numero).value = "";
    document.getElementById(numero).style.border = "1px solid red";
    document.getElementById(numero).placeholder = "*Valor inválido*";
}else{
    document.getElementById(numero).style.color = '#00ad5f';
    document.getElementById(numero).style.border = "1px solid #00ad5f";
}}
// FUNÇÃO DE OCULTAR E MOSTRAR[ utilizado na lista de VM em Cadastro Animal]
/////////////////////////////////////////////////////////////////////////////
 function Block(OnOff){
    var nameTrue = OnOff;
    document.getElementById(nameTrue).style.display = "block";
    }
///////////////////////////////////////////////////////////////////////////////
 function Hidden(OnOff){
    var nameTrue = OnOff;
    document.getElementById(nameTrue).style.display = "none";
 }
// FUNÇÃO PARA FAZER SURGIR UM CAMPO E OCULTAR OS OUTROS CAMPOS VISIVEIS
        // --> EXTENSO: PROCURAR FAZER AS MESMAS ALTERAÇÕES BASEADAS EM 'CLASS'
            // --> POSSIVEL SOLUÇÃO: FAZER UM ARRAY PARA VERIFICAR CASO A VARIAVEL ESTEJA VAZIA; FAZER UM WHILE( enquanto a variavel != null){ comandos }
 function Switch(surgir, sumir, sumir2, sumir3, sumir4, sumir5){

    document.getElementById(surgir).style.display = "block";
    caso =  [sumir,sumir2, sumir3, sumir4, sumir5];
    for(cont = 0; caso[cont] != null; cont++){ document.getElementById(caso[cont]).style.display = "none"; }
    
 }
// FUNÇÃO PARA FAZER SURGIR DOIS CAMPOS
        // --> EXTENSO: PROCURAR FAZER AS MESMAS ALTERAÇÕES BASEADAS EM 'CLASS'
 function Switch2(surgir, surgir2, sumir2, sumir3, sumir4, sumir5){

    caso =  [surgir, surgir2];
    for(cont = 0; caso[cont] != null; cont++){ document.getElementById(caso[cont]).style.display = "block"; }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    caso =  [sumir2, sumir3, sumir4, sumir5];
    for(cont = 0; caso[cont] != null; cont++){ document.getElementById(caso[cont]).style.display = "none"; }
 }

// FUNÇÃO PARA ALTERNAR CORES DE 'ATIVAÇÃO'
    // --> EXTENSO: PROCURAR FAZER AS MESMAS ALTERAÇÕES BASEADAS EM 'CLASS'
 function alternarCor(frag1,frag2,frag3,frag4){

    document.getElementById(frag1).style.color = '#00ad5f';

    caso =  [frag2, frag3, frag4];
    for(cont = 0; caso[cont] != null; cont++){ document.getElementById(caso[cont]).style.color = "#bbb"; }
 }

// FUNÇÃO PARA BLOQUEAR UM CAMPO
 function DS(var1){
    var var1 = var1;
    document.getElementById(var1).style.border = "1px solid red";
    document.getElementById(var1).style.color = "red";
    ///////////////////////////////////////////////////////////////
    var passwordField = $('#'+var1);
    passwordField.attr('disabled', 'true');
    }

function msg(){
    alerta("Oops, esta parte está sendo trabalhada no momento....");
}